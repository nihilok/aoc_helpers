# Advent of Code Helpers

```python3
from aoc_helpers import get_input

def parse_input():
    day_5_input = get_input(5)
    ...
```

When first running you will be asked for your session key, which can be obtained via a browser.